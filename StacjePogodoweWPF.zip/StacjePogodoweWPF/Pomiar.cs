using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace StacjePogodoweWPF;

public class Pomiar : INotifyPropertyChanged
{
    private bool _isMax;
    private bool _isMin;

    public string IdStacji { get; set; } = "";
    public DateTime Data { get; set; }
    public double Temperatura { get; set; }
    public double Wiatr { get; set; }

    public bool IsMax
    {
        get => _isMax;
        set { _isMax = value; OnPropertyChanged(); }
    }

    public bool IsMin
    {
        get => _isMin;
        set { _isMin = value; OnPropertyChanged(); }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

using System.Windows;

namespace StacjePogodoweWPF;

public partial class App : Application
{
}

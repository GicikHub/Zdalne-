STACJE POGODOWE — WPF / C#

Wymagania:
- Visual Studio 2022 z zainstalowanym workloadem „Programowanie aplikacji klasycznych .NET”
- .NET 8 SDK

Uruchomienie:
1. Rozpakuj archiwum.
2. Otwórz plik StacjePogodoweWPF.csproj w Visual Studio 2022.
3. Poczekaj na przywrócenie zależności.
4. Uruchom aplikację klawiszem F5.

Plik data.txt jest kopiowany do katalogu wyjściowego podczas kompilacji.
Aplikacja wczytuje dane z data.txt.
Przycisk „Zapisz pomiary” zapisuje aktualną listę do pomiary_zapisane.txt
w katalogu uruchomieniowym aplikacji.

Format jednego rekordu:
ID_STACJI; RRRR-MM-DD; TEMPERATURA; WIATR;

Temperatury MAX są podświetlane na zielono, MIN na czerwono.

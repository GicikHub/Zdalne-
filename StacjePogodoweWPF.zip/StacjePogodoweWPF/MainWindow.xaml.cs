using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace StacjePogodoweWPF;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<Pomiar> _pomiary = new();
    private readonly string _plikWejsciowy =
        Path.Combine(AppContext.BaseDirectory, "data.txt");
    private readonly string _plikWyjsciowy =
        Path.Combine(AppContext.BaseDirectory, "pomiary_zapisane.txt");

    public MainWindow()
    {
        InitializeComponent();
        DataPicker.SelectedDate = DateTime.Today;
        PomiaryGrid.ItemsSource = _pomiary;
        WczytajDane(_plikWejsciowy, pokazKomunikat: false);
        OdswiezFiltr();
    }

    private void WczytajDane(string sciezka, bool pokazKomunikat)
    {
        if (!File.Exists(sciezka))
        {
            if (pokazKomunikat)
                MessageBox.Show($"Nie znaleziono pliku:\n{sciezka}", "Błąd",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        _pomiary.Clear();
        int numerLinii = 0;
        int bledne = 0;

        foreach (string linia in File.ReadLines(sciezka))
        {
            numerLinii++;
            if (string.IsNullOrWhiteSpace(linia))
                continue;

            // Format: STA1; 2026-03-01; 18.5; 12.5;
            string[] pola = linia.Split(';');
            if (pola.Length < 4 ||
                !DateTime.TryParseExact(pola[1].Trim(), "yyyy-MM-dd",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime data) ||
                !double.TryParse(pola[2].Trim(), NumberStyles.Float,
                    CultureInfo.InvariantCulture, out double temperatura) ||
                !double.TryParse(pola[3].Trim(), NumberStyles.Float,
                    CultureInfo.InvariantCulture, out double wiatr) ||
                string.IsNullOrWhiteSpace(pola[0]))
            {
                bledne++;
                continue;
            }

            _pomiary.Add(new Pomiar
            {
                IdStacji = pola[0].Trim(),
                Data = data,
                Temperatura = temperatura,
                Wiatr = wiatr
            });
        }

        OdswiezFiltr();
        AktualizujMaxMin();

        if (pokazKomunikat)
            MessageBox.Show($"Wczytano pomiary: {_pomiary.Count}\nPominięte błędne wiersze: {bledne}",
                "Wczytywanie zakończone", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void Wczytaj_Click(object sender, RoutedEventArgs e)
        => WczytajDane(_plikWejsciowy, pokazKomunikat: true);

    private void Zapisz_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            using var writer = new StreamWriter(_plikWyjsciowy, false);
            foreach (Pomiar p in _pomiary)
            {
                writer.WriteLine(string.Join("; ",
                    p.IdStacji,
                    p.Data.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                    p.Temperatura.ToString("0.0", CultureInfo.InvariantCulture),
                    p.Wiatr.ToString("0.0", CultureInfo.InvariantCulture)) + ";");
            }

            MessageBox.Show($"Zapisano {_pomiary.Count} pomiarów do pliku:\n{_plikWyjsciowy}",
                "Zapis zakończony", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Nie udało się zapisać pliku:\n{ex.Message}", "Błąd",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void Dodaj_Click(object sender, RoutedEventArgs e)
    {
        string id = IdStacjiBox.Text.Trim();

        if (string.IsNullOrWhiteSpace(id) || DataPicker.SelectedDate is null ||
            !double.TryParse(TemperaturaBox.Text.Trim().Replace(',', '.'),
                NumberStyles.Float, CultureInfo.InvariantCulture, out double temperatura) ||
            !double.TryParse(WiatrBox.Text.Trim().Replace(',', '.'),
                NumberStyles.Float, CultureInfo.InvariantCulture, out double wiatr))
        {
            MessageBox.Show("Uzupełnij poprawnie ID stacji, datę, temperaturę i wiatr.",
                "Niepoprawne dane", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        _pomiary.Add(new Pomiar
        {
            IdStacji = id,
            Data = DataPicker.SelectedDate.Value,
            Temperatura = temperatura,
            Wiatr = wiatr
        });

        OdswiezFiltr();
        AktualizujMaxMin();

        TemperaturaBox.Clear();
        WiatrBox.Clear();
    }

    private void OdswiezFiltr()
    {
        string? poprzedniWybor = FiltrCombo.SelectedItem as string;
        var stacje = _pomiary.Select(p => p.IdStacji)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x)
            .ToList();

        FiltrCombo.SelectionChanged -= FiltrCombo_SelectionChanged;
        FiltrCombo.Items.Clear();
        FiltrCombo.Items.Add("Wszystkie stacje");

        foreach (string stacja in stacje)
            FiltrCombo.Items.Add(stacja);

        FiltrCombo.SelectedItem = poprzedniWybor != null &&
                                  FiltrCombo.Items.Contains(poprzedniWybor)
            ? poprzedniWybor
            : "Wszystkie stacje";

        FiltrCombo.SelectionChanged += FiltrCombo_SelectionChanged;
        ZastosujFiltr();
    }

    private void FiltrCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        => ZastosujFiltr();

    private void ZastosujFiltr()
    {
        if (PomiaryGrid is null)
            return;

        string? stacja = FiltrCombo.SelectedItem as string;
        if (string.IsNullOrEmpty(stacja) || stacja == "Wszystkie stacje")
            PomiaryGrid.ItemsSource = _pomiary;
        else
            PomiaryGrid.ItemsSource = _pomiary.Where(p =>
                p.IdStacji.Equals(stacja, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    private void AktualizujMaxMin()
    {
        if (_pomiary.Count == 0)
            return;

        double max = _pomiary.Max(p => p.Temperatura);
        double min = _pomiary.Min(p => p.Temperatura);

        foreach (Pomiar p in _pomiary)
        {
            p.IsMax = p.Temperatura == max;
            p.IsMin = p.Temperatura == min;
        }
    }

    private void MaxMin_Click(object sender, RoutedEventArgs e)
    {
        if (_pomiary.Count == 0)
        {
            MessageBox.Show("Brak pomiarów w bazie.", "Informacja",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        AktualizujMaxMin();
        Pomiar max = _pomiary.OrderByDescending(p => p.Temperatura).First();
        Pomiar min = _pomiary.OrderBy(p => p.Temperatura).First();

        MessageBox.Show(
            $"MAKSIMUM: {max.Temperatura:F1} °C — {max.IdStacji}, {max.Data:yyyy-MM-dd}\n" +
            $"MINIMUM: {min.Temperatura:F1} °C — {min.IdStacji}, {min.Data:yyyy-MM-dd}\n\n" +
            "W tabeli maksimum jest zielone, a minimum czerwone.",
            "Temperatury MAX / MIN", MessageBoxButton.OK, MessageBoxImage.Information);
    }
}
